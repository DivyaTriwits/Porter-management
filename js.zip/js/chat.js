$(function() {
	'use strict'
	const ps = new PerfectScrollbar('#ChatList', {
		suppressScrollX: true
	});
	const ps12 = new PerfectScrollbar('#ChatCalls', {
		suppressScrollX: true
	});
	const ps13 = new PerfectScrollbar('#ChatContacts', {
		suppressScrollX: true
	});
	const ps1 = new PerfectScrollbar('#ChatBody', {
		suppressScrollX: true
	});
	
	
	
	
});